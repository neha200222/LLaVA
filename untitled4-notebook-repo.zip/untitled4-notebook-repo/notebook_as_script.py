# Generated from Untitled4.ipynb
# Timestamp: 2025-08-29T14:40:18.584494

# %% Cell 1
!pip uninstall -y transformers tokenizers huggingface_hub

# %% Cell 2
# UNINSTALL conflicting libraries
!pip uninstall -y transformers tokenizers diffusers huggingface_hub gradio peft

# INSTALL compatible set (TESTED WORKING together)
!pip install \
  transformers==4.35.2 \
  diffusers==0.25.0 \
  huggingface_hub==0.20.3 \
  tokenizers==0.13.3 \
  peft==0.7.1 \
  accelerate==0.30.1 \
  gradio==3.50.2 \
  safetensors==0.4.2 \
  --quiet


# %% Cell 3
# === Install deps ===
!pip install -q transformers accelerate diffusers gradio==3.50.2 safetensors

# === Import libraries ===
import torch
from transformers import AutoProcessor, LlavaForConditionalGeneration
from diffusers import StableDiffusionPipeline
from PIL import Image
import gradio as gr

# === Load LLaVA model ===
llava_id = "llava-hf/llava-1.5-7b-hf"
processor = AutoProcessor.from_pretrained(llava_id)
llava_model = LlavaForConditionalGeneration.from_pretrained(
    llava_id,
    torch_dtype=torch.float16,
    device_map="cuda",
    low_cpu_mem_usage=True
)

# === Load SD Turbo ===
sd_pipe = StableDiffusionPipeline.from_pretrained(
    "stabilityai/sd-turbo",
    torch_dtype=torch.float16
).to("cuda")
sd_pipe.enable_model_cpu_offload()

# === Define interaction functions ===

def llava_qa(image, question):
    if image is None or not question.strip():
        return "Please upload/draw an image and ask a question."

    prompt = "<image>\n" + question
    image = image.convert("RGB")
    inputs = processor(text=prompt, images=image, return_tensors="pt").to("cuda", torch.float16)
    output = llava_model.generate(**inputs, max_new_tokens=100)
    response = processor.decode(output[0], skip_special_tokens=True)
    return response

def generate_similar_image(image):
    # We'll ask LLaVA to generate a caption first
    prompt = "<image>\nDescribe this image in detail."
    image = image.convert("RGB")
    inputs = processor(text=prompt, images=image, return_tensors="pt").to("cuda", torch.float16)
    output = llava_model.generate(**inputs, max_new_tokens=100)
    description = processor.decode(output[0], skip_special_tokens=True)

    # Feed that description to SD
    result = sd_pipe(prompt=description, num_inference_steps=1, guidance_scale=0.0)
    return result.images[0]

# === Gradio UI ===

with gr.Blocks(title="Creative AI Studio") as demo:
    gr.Markdown("## 🎨 Draw or Upload → 🦙 Chat with LLaVA → 🎇 Get Inspired by SD Turbo")
    with gr.Row():
        # LEFT: Human Canvas
        with gr.Column(scale=1):
            gr.Markdown("### ✍️ Human Canvas")
            canvas = gr.Image(label="Draw or Upload", tool="editor", type="pil")

        # RIGHT: Chat + Inspiration
        with gr.Column(scale=1):
            with gr.Tab("🦙 LLaVA Chat"):
                question = gr.Textbox(label="Ask LLaVA something about the image")
                llava_output = gr.Textbox(label="LLaVA says:")

                btn_qa = gr.Button("Ask")
                btn_qa.click(fn=llava_qa, inputs=[canvas, question], outputs=llava_output)

            with gr.Tab("🌅 AI Inspiration Panel"):
                sd_output = gr.Image(label="AI Inspired Image")
                btn_gen = gr.Button("Generate Inspiration")
                btn_gen.click(fn=generate_similar_image, inputs=canvas, outputs=sd_output)

demo.launch(share=True)


# %% Cell 4


