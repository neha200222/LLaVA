# Untitled4 Notebook

This repository was generated from `Untitled4.ipynb`.

## Contents
- `Untitled4.ipynb` — original Jupyter notebook
- `notebook_as_script.py` — linearized Python script version of code cells
- `requirements.txt` — inferred dependencies from imports (edit as needed)
- `.gitignore` — ignores common cache/virtualenv files

## Setup

```bash
python -m venv .venv
source .venv/bin/activate  # Windows: .venv\Scripts\activate
pip install --upgrade pip
pip install -r requirements.txt
```

To run the notebook:
```bash
pip install notebook ipykernel
jupyter notebook
```

## Reproducing

If your notebook depends on data files or environment variables, add those details here.
You may also want to pin exact versions in `requirements.txt`.

## Convert Notebook to Script

A quick script version is provided in `notebook_as_script.py` for CLI use or CI.
If you prefer using nbconvert:
```bash
pip install nbconvert
jupyter nbconvert --to script Untitled4.ipynb
```

## Push to GitHub

1. Create a new GitHub repo (empty) named `untitled4-notebook-repo`.
2. Run the helper script below or the commands afterward.

### Using the helper script

```bash
bash push_to_github.sh <your-github-username> <repo-name>  # e.g., bash push_to_github.sh rohit-savalgi untitled4-notebook-repo
```

### Manual commands

```bash
git init
git add .
git commit -m "Initial commit: notebook + script + requirements"
git branch -M main
git remote add origin https://github.com/<your-github-username>/<repo-name>.git
git push -u origin main
```
