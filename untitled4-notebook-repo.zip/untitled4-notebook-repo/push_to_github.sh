#!/usr/bin/env bash
set -euo pipefail

if [ $# -lt 2 ]; then
  echo "Usage: bash push_to_github.sh <github-username> <repo-name>"
  exit 1
fi

USER="$1"
REPO="$2"

git init
git add .
git commit -m "Initial commit: notebook + script + requirements"
git branch -M main
git remote add origin "https://github.com/${USER}/${REPO}.git"
git push -u origin main
